<img src="{{ asset('Logo-PAMR.png') }}" {{ $attributes }} alt="Logo PAMR">
